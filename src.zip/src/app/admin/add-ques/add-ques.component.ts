import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-ques',
  templateUrl: './add-ques.component.html',
  styleUrls: ['./add-ques.component.css']
})
export class AddQuesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
