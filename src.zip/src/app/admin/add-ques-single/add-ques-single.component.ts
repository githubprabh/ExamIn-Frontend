import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-ques-single',
  templateUrl: './add-ques-single.component.html',
  styleUrls: ['./add-ques-single.component.css']
})
export class AddQuesSingleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
