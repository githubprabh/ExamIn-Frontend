export class Response {
    temp: String[];
    constructor( response : String[]) {
         this.temp = response;
       }
}