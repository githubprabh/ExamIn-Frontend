export class LoginDetails{
     email: String;
     password: String;
    LoginDetails(email: String, password:String){
        this.email = email;
        this.password = password;
    }
}