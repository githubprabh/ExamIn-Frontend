export class Status{
    status: any;
    message: any;
    studentId:any;
    name:any;
}