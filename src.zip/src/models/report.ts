export class Report {
    studentId:any;
    subjectId:number;
}
