export class ResponseModel{
    answes : number[];
    credentials: string[];
}