export class Question {
    subjectId: any;
}