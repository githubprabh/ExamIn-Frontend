export class Student {
    name: any;
    email : any;
    password: any;
    phoneNo: any;
    dob: any;
    state: any;
    qualification: any;
    city: any;
    yearCompletion: any;
}